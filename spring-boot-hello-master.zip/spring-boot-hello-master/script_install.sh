#!/bin/sh
cd /home/ec2-user/application
sudo ./mvnw install
