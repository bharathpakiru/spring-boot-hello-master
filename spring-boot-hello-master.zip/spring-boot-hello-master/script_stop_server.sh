#!/usr/bin/env bash

sudo killall java
exit 0