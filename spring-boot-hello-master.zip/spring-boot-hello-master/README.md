# spring-boot-hello

Step 1 Install Java JDK if not already installed. The project already contains maven wrapper so you do not need to install maven. You just need to have java JDK 8 on your machine.

Step 2 CD into the project
</br>
Step 3
./mvnw package
</br>
Step 4
./mvnw spring-boot:run

</br>
Step 5
http://localhost:8080 in your browser

